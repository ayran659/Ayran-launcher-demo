# Ayran Launcher

Mobile Minecraft Java launcher with an original Ayran interface.

- Ayran main menu and branding
- Minecraft version selector
- Mods browser with Modrinth/CurseForge integration
- Fabric/Forge/NeoForge-related launcher support from the underlying engine
- ARM64 build for Android tablets/phones

Build with GitHub Actions using `:app_pojavlauncher:assembleDebug`.
